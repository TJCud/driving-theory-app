<?php
require "db_methods.php";
$db = new DataBase();
    if ($db->dbConnect()) {
        if ($db->saveUser($_POST['id'] ?? null,$_POST['type'] ?? null,$_POST['username'] ?? null,$_POST['password'] ?? null,$_POST['email'] ?? null,$_POST['date'] ?? null,$_POST['typeID'] ?? null)) {
            echo "Save Success";
        } else echo "Save Failed";
    } else echo "Error: Database connection";
?>