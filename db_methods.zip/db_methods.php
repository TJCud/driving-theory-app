<?php
require "db_config.php";

class DataBase
{
    public $connect;
    public $data;
    private $sql;
    protected $servername;
    protected $username;
    protected $password;
    protected $databasename;

    public function __construct()
    {
        $this->connect = null;
        $this->data = null;
        $this->sql = null;
        $dbc = new DataBaseConfig();
        $this->servername = $dbc->servername;
        $this->username = $dbc->username;
        $this->password = $dbc->password;
        $this->databasename = $dbc->databasename;
    }

    function dbConnect()
    {
        $this->connect = mysqli_connect($this->servername, $this->username, $this->password, $this->databasename);
        return $this->connect;
    }

    function prepareData($data)
    {
        return mysqli_real_escape_string($this->connect, stripslashes(htmlspecialchars($data)));
    }

    function logIn($table, $username, $password)
    {
        $username = $this->prepareData($username);
        $password = $this->prepareData($password);
        $this->sql = "select * from " . $table . " where username = '" . $username . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);
        if (mysqli_num_rows($result) != 0) {
            $dbusername = $row['username'];
            $dbpassword = $row['password'];
            if ($dbusername == $username && password_verify($password, $dbpassword)) {
                $login = true;
            } else $login = false;
        } else $login = false;

        return $login;
    }

    function signUp($table, $email, $username, $password, $date)
    {
        $username = $this->prepareData($username);
        $password = $this->prepareData($password);
        $email = $this->prepareData($email);
		$date = $this->prepareData($date);
        $password = password_hash($password, PASSWORD_DEFAULT);
        $this->sql =
            "INSERT INTO " . $table . " (username, password, email, date) VALUES ('" . $username . "','" . $password . "','" . $email . "','" . $date . "')";
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }
	
	
    function saveResults($username, $questionsCorrect, $questionsTotal, $outcome, $date, $savedQuestions)
    {
        $username = $this->prepareData($username);
        $questionsCorrect = $this->prepareData($questionsCorrect);
        $questionsTotal = $this->prepareData($questionsTotal);
        $outcome = $this->prepareData($outcome);
        $date = $this->prepareData($date);
        $savedQuestions = $this->prepareData($savedQuestions);
        $this->sql =
            "INSERT INTO results (username, questionsCorrect, questionsTotal, outcome, data, savedQuestions) VALUES ('Cardinal',1,1,'PASS','now','test')";
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }



    function getResults($username)
    {

        $username = $this->prepareData($username);

        $this->sql = "SELECT id, username, questionsCorrect, questionsTotal, outcome, date, savedQuestions FROM results WHERE username = '$username'";


            $sth = mysqli_query($this->connect,$this->sql);
            $rows = array();
            while($r = mysqli_fetch_assoc($sth)) {
                $rows[] = $r;
            }
            echo json_encode(['resultdata' => $rows]);

    }



    function checkUserExists($username){

        $username = $this->prepareData($username);

        $this->sql = "SELECT * FROM users WHERE username = '$username'";

        $sth = mysqli_query($this->connect,$this->sql);
        if(mysqli_num_rows($sth) > 0){
            return false;
        } else return true;
    }


    function checkEmailExists($email){

        $email = $this->prepareData($email);

        $this->sql = "SELECT * FROM users WHERE email = '$email'";

        $sth = mysqli_query($this->connect,$this->sql);
        if(mysqli_num_rows($sth) > 0){
            return false;
        } else return true;
    }




 function getcategory($category)
    {

        $category = $this->prepareData($category);

        $this->sql = "SELECT id, category, question, option1, option2, option3, option4, answer, image, explanation FROM exam_questions WHERE category = '$category'";


            $sth = mysqli_query($this->connect,$this->sql);
            $rows = array();
            while($r = mysqli_fetch_assoc($sth)) {
                $rows[] = $r;
            }
            echo json_encode(['categorydata' => $rows]);

	if (mysqli_num_rows($sth) != 0) {
             return true;}
	else return false;



    }



function getallusers()
    {


        $this->sql = "SELECT * FROM users";


            $sth = mysqli_query($this->connect,$this->sql);
            $rows = array();
            while($r = mysqli_fetch_assoc($sth)) {
                $rows[] = $r;
            }
            echo json_encode(['allusersdata' => $rows]);

	if (mysqli_num_rows($sth) != 0) {
             return true;}
	else return false;



    }



function getAllQuestions()
    {

        function utf8ize($d) {
            if (is_array($d)) {
                foreach ($d as $k => $v) {
                    $d[$k] = utf8ize($v);
                }
            } else if (is_string ($d)) {
                return utf8_encode($d);
            }
            return $d;
        }

        $this->sql = "SELECT id, category, question, option1, option2, option3, option4, answer, image, explanation FROM exam_questions";
        $sth = mysqli_query($this->connect,$this->sql);


        $rows = array();
        while($r = mysqli_fetch_assoc($sth)) {
            $rows[] = $r;
        }
        echo json_encode(utf8ize(['getAllQuestions' => $rows]),JSON_NUMERIC_CHECK);

        if (mysqli_num_rows($sth) != 0) {
            return true;}
        else return false;
        
    }



    function getQuestionByID($ID)
    {

        $ID = $this->prepareData($ID);

        $this->sql = "SELECT * FROM exam_questions WHERE ID = '$ID'";

            $sth = mysqli_query($this->connect,$this->sql);
            $rows = array();
            while($r = mysqli_fetch_assoc($sth)) {
                $rows[] = $r;
            }
            echo json_encode(['questionDataByID' => $rows]);


	if (mysqli_num_rows($sth) != 0) {
             return true;}
	else return false;
      

    }


    function saveQuestion($ID, $category, $question, $option1, $option2, $option3, $option4, $answer, $image, $explanation, $categoryID)
    {
        
	$ID = $this->prepareData($ID);
	$category = $this->prepareData($category);
        $question = $this->prepareData($question);
        $option1 = $this->prepareData($option1);
        $option2 = $this->prepareData($option2);
        $option3 = $this->prepareData($option3);
        $option4 = $this->prepareData($option4);
        $answer = $this->prepareData($answer);
        $image = $this->prepareData($image);
        $explanation = $this->prepareData($explanation);
        $categoryID = $this->prepareData($categoryID);
   
        $this->sql = "INSERT INTO exam_questions (id, category, question, option1, option2, option3, option4, answer, image, explanation, categoryID) VALUES ('$ID','$category','$question','$option1','$option2','$option3','$option4','$answer','$image','$explanation','$categoryID') ON DUPLICATE KEY UPDATE category = VALUES (category), question = VALUES (question), option1 = VALUES (option1), option2 = VALUES (option2), option3 = VALUES (option3), option4 = VALUES (option4), answer = VALUES (answer), image = VALUES (image), explanation = VALUES (explanation), categoryID = VALUES (categoryID)";
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }



    function saveUser($ID, $type, $username, $password, $email, $date, $typeID)
    {
        $ID = $this->prepareData($ID);
	$type = $this->prepareData($type);
        $username = $this->prepareData($username);
        $email = $this->prepareData($email);
	$date = $this->prepareData($date);
	$password = password_hash($password, PASSWORD_DEFAULT);
	$typeID = $this->prepareData($typeID);
   
   
        $this->sql = "INSERT INTO users (id, type, username, password, email, date, typeID) VALUES ('$ID', '$type', '$username','$password','$email','$date', '$typeID') ON DUPLICATE KEY UPDATE type = VALUES (type),username = VALUES (username), email = VALUES (email), date = VALUES (date),typeID = VALUES (typeID)";
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }


    function getUserByID($ID)
    {

        $ID = $this->prepareData($ID);

        $this->sql = "SELECT * FROM users WHERE ID = '$ID'";

            $sth = mysqli_query($this->connect,$this->sql);
            $rows = array();
            while($r = mysqli_fetch_assoc($sth)) {
                $rows[] = $r;
            }
           


	if (mysqli_num_rows($sth) != 0) {
	 echo json_encode(['userDataByID' => $rows]);
             return true;}
	else return false;
     
    }



    function deleteAccount($table, $username)
    {
        $username = $this->prepareData($username);
        $this->sql =
            "DELETE FROM " . $table . " WHERE username ='" . $username . "'";
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }


    function updatePassword($username, $password)
    {
        $username = $this->prepareData($username);
        $password = $this->prepareData($password);
        $password = password_hash($password, PASSWORD_DEFAULT);

        $this->sql = "UPDATE users SET password= '" . $password ."' WHERE username ='" . $username . "'";


        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }




}
	
	