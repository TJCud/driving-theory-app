<?php
require "db_methods.php";
$db = new DataBase();
if (isset($_POST['username'])&&isset($_POST['password'])) {
    if ($db->dbConnect()) {
        if ($db->updatePassword($_POST['username'],$_POST['password'])) {
            echo "Password Successfully Updated";
        } else echo "Password Update Failed";
    } else echo "Error: Database connection";
} else echo "All fields are required";
