<?php

class DataBaseConfig
{
    public $servername;
    public $username;
    public $password;
    public $databasename;

    public function __construct()
    {

        $this->servername = 'localhost';
        $this->username = 'tcudden01';
        $this->password = '62GdFd9cRBdPh1ft';
        $this->databasename = 'tcudden01';

    }
}

?>
