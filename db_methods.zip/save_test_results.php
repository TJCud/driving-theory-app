<?php

$servername = 'localhost';
$username = 'tcudden01';
$password = '62GdFd9cRBdPh1ft';
$dbname = 'tcudden01';


// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$username = $_POST["username"];
$questionsCorrect= $_POST['questions_correct'];
$questionsTotal = $_POST['questions_total'];
$outcome = $_POST['outcome'];
$date =  $_POST['date'];
$savedQuestions=  $_POST['saved_question'];


/*$username = "test";
$questionsCorrect= 1;
$questionsTotal = 1;
$outcome = "fail";
$date =  "yesterday";
$savedQuestions=  "all of them";*/


$sql =
    "INSERT INTO results (username, questionsCorrect, questionsTotal, outcome, date, savedQuestions) VALUES 
    ('" . $username . "','" . $questionsCorrect . "','" . $questionsTotal . "','" . $outcome . "','" . $date . "','" . $savedQuestions . "')";


if (mysqli_query($conn, $sql)) {
    echo "success";
} else echo "fail";
