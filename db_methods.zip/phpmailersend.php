<?php


// Can be setup to use the QUB O365 SMTP Mail Servers.
// You must use your student account to authenticate.
// For Multi-factor Authenication setup and use an O365 App Password.
//
// Replace the placeholders:
// <SENDEREMAILADDRESS> your QUB email address
// <SENDERNAME> your QUB email address
//
// <RECIPENTEMAIL> a test email address to send to - use your qub email address address
// <RECIPIENTNAME> a recipient name to test with

//Use the following exact namespaces no matter which directory your phpmailer files are in.
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;



// Now include the followingfiles based on the correct file path.
// SMTP.php is required to enable SMTP.
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'db_config.php';

$mail = new PHPMailer(true);

//$mail->SMTPDebug = 3;                               // Enable verbose debug output
$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';  				  // Specify QUB O365 SMTP servers
$mail->SMTPAuth = true;                              // Enable SMTP authentication
$mail->Username = 'drivingtestsuccessapp@gmail.com';         // SMTP username
$mail->Password = 'PASS4qub';         // SMTP password
$mail->SMTPSecure = 'tls';                          // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                                     // TCP port to connect to
//FROM
$mail->From = 'drivingtestsuccessapp@gmail.com';                 // user your QUB email address
$mail->FromName = 'drivingtestsuccessapp@gmail.com';                     // use your name or app name





//Generate random string of 6 characters
function generateRandomString($length = 6): string
{
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}


$resetCode = generateRandomString(6);
$passwordHash = $resetCode; // Password to be hashed



//Server details
$servername = 'localhost';
$username = 'tcudden01';
$password = '62GdFd9cRBdPh1ft';
$dbname = 'tcudden01';


//Getting users email
$email = $_POST["email"];


// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


//Query to check if user exists on system
$sql = "SELECT email from users WHERE email = '" . $email . "'";
$result = mysqli_query($conn, $sql);


//If the user exists , proceed with next steps
if ($result->num_rows >0) {

    //Hash the password and update existing password
    $passwordHash = password_hash($passwordHash, PASSWORD_DEFAULT);
    $sqlUpdatePassword = "UPDATE users SET password= '" . $passwordHash ."' WHERE email ='" . $email . "'";
    mysqli_query($conn, $sqlUpdatePassword);


    // RECIPIENTS
    $mail->addAddress($email); // Add a recipient


// MESSAGE DETAILS
    $mail->WordWrap = 50;                                 // Set word wrap to 50 characters
    $mail->isHTML(true);                                  // Set email format to HTML


// Message to be sent
    $message = '<p>We received a password reset request. Your new password is below. ';
    $message .= 'Please change your password when you log in again.</p>';
    $message .= '<p>Here is your new password: </br>';
    $message .= '' . $resetCode . '</p>';
    $mail->Subject = 'Password Reset Request';
    $mail->Body    = $message;
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';


    //Check if email was sent correctly
    if(!$mail->send()) {
        echo 'Email could not be sent.';
        echo 'Mailer Error: ' . $mail->ErrorInfo;
    } else {
        echo 'Email has been sent';
    }



} else echo 'Error';

















