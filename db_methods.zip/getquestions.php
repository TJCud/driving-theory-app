<?php header('Content-type:application/json; charset:utf-8');
$servername = "localhost";
$username = "tcudden01";
$password = '62GdFd9cRBdPh1ft';
$dbname = "tdcudden01";

function utf8ize($d) {
  if (is_array($d)) {
     foreach ($d as $k => $v) {
       $d[$k] = utf8ize($v);
     }
  } else if (is_string ($d)) {
     return utf8_encode($d);
  }
   return $d;
}


// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT id, category, question, option1, option2, option3, option4, answer, image, explanation FROM exam_questions";
$result = $conn->query($sql);


$sth = mysqli_query($conn, $sql);
$rows = array();
while($r = mysqli_fetch_assoc($sth)) {
    $rows[] = $r;
}
echo json_encode(utf8ize(['questiondata' => $rows]),JSON_NUMERIC_CHECK);

$conn->close();
?>