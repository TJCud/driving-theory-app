<?php
require "DataBase.php";
$db = new DataBase();
    if ($db->dbConnect()) {
        if ($db->saveQuestion($_POST['id'],$_POST['category'], $_POST['question'], $_POST['option1'],$_POST['option2'],$_POST['option3'],$_POST['option4'],$_POST['answer'],$_POST['image'],$_POST['explanation'],$_POST['categoryID'])) {
            echo "Success";
        } else echo "Failed";
    } else echo "Error: Database connection";
?>