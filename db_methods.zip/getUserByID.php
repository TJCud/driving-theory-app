<?php
require "db_methods.php";
$db = new DataBase();
    if ($db->dbConnect()) {
        if ($db->getUserByID($_POST['ID'] ?? null)) {
            echo "Retrieval Success";
        } else echo "No Users found";
    } else echo "Error: Database connection";
?>