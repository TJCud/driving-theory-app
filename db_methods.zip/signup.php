<?php
require "db_methods.php";
$db = new DataBase();
if (isset($_POST['email']) && isset($_POST['username']) && isset($_POST['password']) && isset($_POST['date'])) {
    if ($db->dbConnect()) {
    if ($db->checkUserExists($_POST['username'])) {
        if ($db->checkEmailExists($_POST['email'])) {
            if ($db->signUp("users", $_POST['email'], $_POST['username'], $_POST['password'],$_POST['date'])) {
                echo "Sign Up Success";
            } else echo "Sign up Failed";
        } else echo "That email is taken. Try another.";
    } else echo "That username is taken. Try another.";
    } else echo "Error: Database connection";
} else echo "All fields are required";
