<?php
require "DataBase.php";
$db = new DataBase();
    if ($db->dbConnect()) {
        if ($db->getcategory($_POST['category'])) {
            echo "Success";
        } else echo "Fail";
    } else echo "Error: Database connection";
?>