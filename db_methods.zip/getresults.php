<?php
require "db_methods.php";
$db = new DataBase();
    if ($db->dbConnect()) {
        if ($db->getResults($_POST['username'])) {
            echo "Results Retrieval Success";
        } else echo "No results found";
    } else echo "Error: Database connection";
?>