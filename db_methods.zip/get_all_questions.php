<?php
require "db_methods.php";
$db = new DataBase();
if ($db->dbConnect()) {
    if ($db->getAllQuestions()) {
	echo "success";
    } else echo "no questions found";
} else echo "connection fail";
