<?php
require "db_methods.php";
$db = new DataBase();
if (isset($_POST['username']) && isset($_POST['questions_correct']) && isset($_POST['questions_total'])&& isset($_POST['outcome'])&& isset($_POST['date']) && isset($_POST['saved_question'])) {
 if ($db->dbConnect()) {
     if ($db->saveResults($_POST['username'],$_POST['questions_correct'], $_POST['questions_total'], $_POST['outcome'],$_POST['date'],$_POST['saved_question'])) {
         echo "success";
     } else echo "fail";
 } else echo "Error: Database connection";
} else echo "Error: Missing data";
