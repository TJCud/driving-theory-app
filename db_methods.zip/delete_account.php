<?php
require "db_methods.php";
$db = new DataBase();
if (isset($_POST['username'])) {
    if ($db->dbConnect()) {
        if ($db->deleteAccount("users",$_POST['username'])) {
            echo "success";
        } else echo "unable to delete account";
    } else echo "Error: Database connection";
} else echo "Error";
