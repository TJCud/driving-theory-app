<?php

// Who are we sending it to.
$to = "tjcud92@gmail.com";

// Subject
$subject = 'Reset your password for mmtuts';

$url = "abc";

// Message
$message = '<p>We received a password reset request. The link to reset your password is below. ';
$message .= 'If you did not make this request, you can ignore this email</p>';
$message .= '<p>Here is your password reset link: </br>';
$message .= '<a href="' . $url . '">' . $url . '</a></p>';

// Headers
// Headers
$headers = "From: mmtuts <tjcud92@gmail.com>\r\n";
$headers .= "Reply-To: tjcud92@gmail.com\r\n";
$headers .= "Content-type: text/html\r\n";

// Send e-mail
if(mail($to, $subject, $message, $headers)){
    echo "success";
} else echo "fail";