<?php
require "db_methods.php";
$db = new DataBase();
    if ($db->dbConnect()) {
        if ($db->getAllUsers()) {
            echo "success";
        } else echo "no users found";
    } else echo "Error: Database connection";
