<?php
require "DataBase.php";
$db = new DataBase();
    if ($db->dbConnect()) {
        if ($db->getQuestionByID($_POST['ID'])) {
            echo "Retrieval Success";
        } else echo "No Questions found";
    } else echo "Error: Database connection";
?>